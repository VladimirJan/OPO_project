#include "verovatnocaPrihvatanja.h"

double verovatnocaPrihvatanja(double staraVrednost, double novaVrednost, double temperatura){
    if (staraVrednost > novaVrednost){
        return 1;
    }

    return exp(-abs(staraVrednost - novaVrednost) / temperatura);
}
