#include"inicijalnoResenje.h"

using namespace arma;

void inicijalnoResenje(int brojPoslova, urowvec& X){

	uvec v = linspace<uvec>(1, brojPoslova, brojPoslova);

    uvec med = randsample(v, brojPoslova);

    X = conv_to<urowvec>::from(med);


}
