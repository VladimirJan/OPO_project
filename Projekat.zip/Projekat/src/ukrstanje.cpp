#include "ukrstanje.h"

using namespace arma;

void ukrstanje(umat P,umat SP, umat& new_P, vec F, vec SF){
	
	int poslovi = P.n_cols;
	int brojJedinki = P.n_rows;
	int pozicijaPreseka = floor(poslovi/2);
	int alfa = floor(0.3 * brojJedinki);
	uvec sort_ind_P = sort_index(F);
	uvec sort_ind_SP = sort_index(SF);
	umat potomci(brojJedinki, poslovi);

	for (int i = 0; i < alfa; i++) {
		potomci.row(i) = SP.row(sort_ind_SP(i));// deset posto selektovanih ide dalje direktno 
	}
	for (int i = 0; i < brojJedinki - alfa; i++) {

		urowvec stara = P.row(sort_ind_P(i));// stara jedinka

		urowvec selektovana = SP.row(sort_ind_SP(i));	//selektovana



		urowvec staraPrviDeo = stara.head(pozicijaPreseka);
		urowvec staraDrugiDeo = stara.tail(pozicijaPreseka);

		urowvec selektovanaPrviDeo = selektovana.head(pozicijaPreseka);
		urowvec selektovanaDrugiDeo = selektovana.tail(pozicijaPreseka);

		urowvec presek = intersect(staraPrviDeo, selektovanaDrugiDeo);

		urowvec staraPrviDeoNovo = setdiff2(staraPrviDeo, presek);
		urowvec selektovanaDrugiDeoNovo = setdiff2(selektovanaDrugiDeo, presek);

		urowvec ostatak = setdiff2(selektovanaPrviDeo, staraPrviDeoNovo);

		urowvec Xhromozom = join_horiz(staraPrviDeoNovo, selektovanaDrugiDeoNovo);
		urowvec Yhromozom = join_horiz(presek, ostatak);

		potomci.row(alfa + i) = join_horiz(Xhromozom, Yhromozom);

	}

	new_P = potomci;

}
