#include "selekcija.h"

using namespace arma;

void selekcija(umat P, umat& new_P, vec F, vec& new_F) {
	int brojJedinki = P.n_rows;
	int brojPoslova = P.n_cols;
	umat SP(brojJedinki, brojPoslova);
	vec SF(brojJedinki);
	int ind;
	uvec index_F = sort_index(F);
	//cout << index_F << endl;
	for (int i = 0; i < brojJedinki; i++) {
		ind = brojJedinki - floor((-1 + sqrt(1 + 4 * randu<double>() * (brojJedinki * brojJedinki + brojJedinki))) * 0.5) - 1; // indeks
		SP.row(i) = P.row(index_F(ind));
		SF(i) = F(index_F(ind));
	}
	new_P = SP;
	new_F = SF;
	//cout << "selekcija:" << endl;
	//cout << new_P << endl;

}
