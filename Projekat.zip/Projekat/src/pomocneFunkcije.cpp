#include "pomocneFunkcije.h"

using namespace arma;

int randint(int i) {
	return randi<int>(distr_param(0, i - 1)); 
}

uvec setdiff(uvec v, uvec u) {
	int l = v.n_elem;
	uvec s(l);
	int k = 0;
	for (int i = 0; i < l; i++) {
		if (all(u != v(i))) {
			s(k) = v(i);
			k += 1;
		}
	}
	if (k == 0) {
		return uvec();
	}
	return s(span(0, k - 1));
}

urowvec setdiff2(urowvec v, urowvec u) {
	int l = v.n_elem;
	urowvec s(l);
	int k = 0;
	for (int i = 0; i < l; i++) {
		if (all(u != v(i))) {
			s(k) = v(i);
			k += 1;
		}
	}
	if (k == 0) {
		urowvec a;
		return a;
	}
	return s(span(0, k - 1));
}

uvec randsample(uvec v, int k) {
	uvec d(k);
	if (k == 1) {
		int ind = randint(v.n_elem);
		d(0) = v(ind);
	}
	else {
		uvec v_shuffle = arma::shuffle(v);
		d = v_shuffle(span(0, k - 1));
	}
	return d;
}
urowvec randsample2(urowvec v, int k) {
	urowvec d(k);
	if (k == 1) {
		int ind = randint(v.n_elem);
		d(0) = v(ind);
	}
	else {
		urowvec v_shuffle = arma::shuffle(v);
		d = v_shuffle(span(0, k - 1));
	}
	return d;
}


