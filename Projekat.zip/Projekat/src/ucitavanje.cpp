#include "ucitavanje.h"

using namespace arma;

void ucitavanje(const char* filename, mat& C, int& brojPoslova, double& T){
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: Unable to open file '%s'\n", filename);
        exit(1);
    }


    if (fscanf(file, "n : %d ", &brojPoslova) != 1) {
        printf("Error");
        exit(1);
    }
    if (fscanf(file, "dm : %lf ", &T) != 1) {
        printf("Error!");
        exit(1);
    }

    C.zeros(brojPoslova + 1, brojPoslova + 1);


    for (int i = 0; i < brojPoslova + 1; i++) {
        for (int j = 0; j < brojPoslova + 1; j++) {
            if (fscanf(file, "%lf", &C(i, j)) != 1) {
                printf("Error.");
                exit(1);
            }
        }
    }

    fclose(file);
}
