#include <stdio.h>
#include <armadillo>
#include <iostream>

#include "ucitavanje.h"
#include "GA.h"
#include "SA.h"
#include "funkcijaCilja.h"

#pragma warning(disable:4996)

using namespace std;
using namespace arma;

int main(){

	int brojPoslova;
	double T;
	mat C;
	double t = 0;
	double elapsedTime = 0;
	double t1 = 0;
	double elapsedTime1 = 0;
	double t2 = 0;
	double elapsedTime2 = 0;
	urowvec X_best; //najbolja jedinka
	int hibridizacija = 0;

	double opt = INFINITY;

	ucitavanje("data/inputFile.txt", C, brojPoslova, T);
    T = 2.5 * T;



    int choice;
    //cout << "Unesite izbor (0 za GA, 1 za SA, 2 za oba): ";
    //cin >> choice;
    choice = 2;

    switch (choice) {
        case 0:
            cout << "Izvrsavanje GA:" << endl;
            GA(brojPoslova, T, C, opt, t1, elapsedTime1, X_best);
            break;
        case 1:
            cout << "Izvrsavanje SA:" << endl;
            SA(brojPoslova, T, C, opt, t2, elapsedTime2, X_best, hibridizacija);
            break;
        case 2:
			hibridizacija = 1;
            cout << "Izvrsavanje GA:" << endl;
            GA(brojPoslova, T, C, opt, t1, elapsedTime1, X_best);
            cout << "Izvrsavanje SA:" << endl;
            SA(brojPoslova, T, C, opt, t2, elapsedTime2, X_best, hibridizacija);
            break;
        default:
            cout << "Nepoznat izbor." << endl;
            break;
    }


	t = t1 + t2;
	elapsedTime = elapsedTime1 + elapsedTime2;

	printf("Najbolje resenje je [ %lf   %lf   %lf] \n", opt, t, elapsedTime);
	cout << "A najbolji  raspored je" << X_best << endl;



  return 0;
}
