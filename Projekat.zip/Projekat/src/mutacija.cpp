#include "mutacija.h"

using namespace arma;

void mutacija(umat& new_G){
	
		int brojJedinki = new_G.n_rows;
		int poslovi = new_G.n_cols;
		for (int i = 0; i < brojJedinki; i++) {
			if (randu<double>() > 0.8) {
				int prvaIzmena = randint(poslovi);
				int drugaIzmena = randint(poslovi);

				while(prvaIzmena == drugaIzmena){
					drugaIzmena = randint(poslovi);
				}

				int temp = new_G(i, prvaIzmena);
				new_G(i,prvaIzmena) = new_G(i,drugaIzmena);
				new_G(i,drugaIzmena) = temp;
			}
		}

} 
