#include "funkcijaCilja.h"

using namespace arma;

void funkcijaCilja (mat C, int n, double T,urowvec x, double& fx){

    int brojBlokova = 0;
    int prethodniPosao = 0;
    double poslednjiBlok = 0;
    double Cmax = 0;


    for(int i = 0; i < n; ++i) {
        int trenutniPosao = x(i);

        // Ako je prvi blok
        if (poslednjiBlok == 0) {
            poslednjiBlok = C(0, trenutniPosao) + C(trenutniPosao, 0);
        } else {
            // Dodavanje vreme rada za posao i izacivanje prethodno odrzavanje
            poslednjiBlok += C(prethodniPosao, trenutniPosao) + C(trenutniPosao, 0) - C(prethodniPosao, 0);
        }

        // Provera za novi blok
        if (poslednjiBlok > T) {
            brojBlokova++;
            poslednjiBlok = C(0, trenutniPosao) + C(trenutniPosao, 0);

        }

        prethodniPosao = trenutniPosao;
    }

    Cmax = poslednjiBlok + brojBlokova * T;
    fx = Cmax;


}
