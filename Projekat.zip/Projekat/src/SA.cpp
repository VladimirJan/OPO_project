#include "SA.h"

using namespace arma;

void SA(int brojPoslova,double T,mat C, double& opt,double& t,double& elapsedTime, urowvec& X_best, int hibridizacija){

    urowvec X_temp = X_best;

    clock_t start = clock();


    if( hibridizacija == 0){
        inicijalnoResenje(brojPoslova, X_temp);
    }

    funkcijaCilja(C,brojPoslova,T,X_temp,opt);


    int maxIter = floor(brojPoslova*brojPoslova);
    int maxIterInner = floor(brojPoslova*brojPoslova/10);
    int temperatura = floor(brojPoslova*sqrt(brojPoslova));

    int poboljsanje = ceil(maxIter/3);

    urowvec novoX;
    double fx;
    double verovatnoca;
    double ohladjivanje = 0.999;

    for(int i = 0; i < maxIter ; i++){

        poboljsanje--;

        clock_t vreme_k = clock();
		if ((double(vreme_k - start) / CLOCKS_PER_SEC) > 3600) {
			cout << "Dostignuto je maksimalno vreme, u algoritmu SA." << endl;
			break;
		}

        for(int j = 0; j< maxIterInner; j++){

		okolinaInverzija(X_temp, novoX);
		okolinaPermutacija(X_temp, novoX);


        funkcijaCilja(C,brojPoslova,T,novoX,fx);

        verovatnoca = verovatnocaPrihvatanja(opt, fx, temperatura);

        if(randu() < verovatnoca){
            X_temp = novoX;
            opt = fx;
            poboljsanje = ceil(maxIter/3);

        }

        if(fx < opt){
            X_temp = novoX;
            opt = fx;
            clock_t vreme_i = clock();
			t = double(vreme_i - start) / CLOCKS_PER_SEC;
            poboljsanje = ceil(maxIter/3);

        }

        }

        if (poboljsanje <= 0) {
			cout << "Nije se desila promena, pa je algoritam SA prekinut." << endl;
			break;
		}
        temperatura = temperatura*ohladjivanje;

    }
    clock_t end = clock();
    elapsedTime = double(end - start) / CLOCKS_PER_SEC;
    X_best = X_temp;

}
