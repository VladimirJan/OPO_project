#include "funkcijaPrilagodjenosti.h"
#include "funkcijaCilja.h"


using namespace arma;

void funkcijaPrilagodjenosti (umat P, vec& F, mat C, double T, int brojPoslova){

    int brojJedinki = P.n_rows;
    vec FP = zeros<vec>(brojJedinki);

    for (int j = 0; j < brojJedinki; j++) {
        funkcijaCilja(C, brojPoslova, T, P.row(j), FP(j));
    }

    F = FP;


}
