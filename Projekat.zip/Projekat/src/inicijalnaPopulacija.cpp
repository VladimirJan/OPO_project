#include "inicijalnaPopulacija.h"

using namespace arma;

void inicijalnaPopulacija(int brojPoslova, double T, umat& P, int brojJedinki) {
	umat X = zeros<umat>(brojJedinki, brojPoslova);
	uvec med;
	uvec v = linspace<uvec>(1, brojPoslova, brojPoslova);
	for (int i = 0; i < brojJedinki ; i++) {
		med = randsample(v, brojPoslova);
		for (int j = 0; j < brojPoslova; j++) {
			X(i, j) = med(j);
		}
	}
	P = X;
}
