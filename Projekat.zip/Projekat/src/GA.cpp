#include "GA.h"

using namespace arma;

void GA(int brojPoslova, double T, mat& C,  double& opt, double& t, double& elapsed_time, urowvec& X_best){

	int brojJedinki = floor(brojPoslova*sqrt(brojPoslova));
	int max_gen = brojJedinki;

	umat P;
	umat new_P;
	umat new_G;
	vec F;
	vec new_F;
	vec new_GF;
	double F_best;

    clock_t start = clock();

	inicijalnaPopulacija(brojPoslova, T, P, brojJedinki);



	funkcijaPrilagodjenosti(P, F, C, T, brojPoslova);


	int ind = F.index_min();
	X_best = P.row(ind);
	F_best = F(ind);
	t = 0;
	int poboljsanje = ceil(max_gen/3);

    for (int i = 0; i < max_gen; i++) {
		poboljsanje--;
		clock_t vreme_k = clock();
		if ((double(vreme_k - start) / CLOCKS_PER_SEC) > 3600) {
			cout << "Dostignuto je maksimalno vreme u GA." << endl;
			break;
		}

		selekcija(P, new_P, F, new_F);


		ukrstanje(P, new_P, new_G, F, new_F);

		mutacija(new_G);

		funkcijaPrilagodjenosti(new_G, new_GF, C, T, brojPoslova);

		P = new_G;
		F = new_GF;

		if (F_best > double(arma::min(F))) {
			ind = F.index_min();
			X_best = P.row(ind);
			F_best = F(ind);
			clock_t vreme_i = clock();
			t = double(vreme_i - start) / CLOCKS_PER_SEC;

            poboljsanje = ceil(max_gen/3);
		}
		if (poboljsanje <= 0) {
			cout << "Nije se desila promena, pa je algoritam GA prekinut." << endl;
			break;
		}

	}



	clock_t end = clock();
	elapsed_time = double(end - start) / CLOCKS_PER_SEC;
    opt = F_best;

}
