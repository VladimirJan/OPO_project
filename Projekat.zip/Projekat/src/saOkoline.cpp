#include"saOkoline.h"

using namespace arma;

void zamena(urowvec X, urowvec& novoX){

    int poslovi = X.n_elem;

    int prvaIzmena = randint(poslovi);

    int drugaIzmena = randint(poslovi);

    while(prvaIzmena == drugaIzmena){

        drugaIzmena = randint(poslovi);

    }

    int temp = X(prvaIzmena);
    X(prvaIzmena) = X(drugaIzmena);
    X(drugaIzmena) = temp;

    novoX = X;
}

void inverzija(urowvec X, urowvec& novoX){

    novoX = reverse(X);

}

void permutacija(urowvec X, urowvec& novoX){

    int poslovi = X.n_elem;

    int temp = X(0);

    for(int i = 0; i < poslovi - 1; i++){

        X(i) = X(i+1);

    }

    X(poslovi-1) =  temp;

    novoX = X;
}

void okolinaInverzija(urowvec X, urowvec& novoX){

    inverzija(X,novoX);

    zamena(X, novoX);
}

void okolinaPermutacija(urowvec X, urowvec& novoX){

    permutacija(X,novoX);

    zamena(X, novoX);
}


