#ifndef GA_H
#define GA_H

#include <armadillo>

#include "pomocneFunkcije.h"
#include "inicijalnaPopulacija.h"
#include "funkcijaCilja.h"
#include "funkcijaPrilagodjenosti.h"
#include "selekcija.h"
#include "ukrstanje.h"
#include "mutacija.h"

using namespace arma;

void GA(int brojPoslova, double T, mat& C, double& opt, double& t, double& elapsed_time, urowvec& X_best);

#endif
