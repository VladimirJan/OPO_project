#ifndef SAOKOLINE_H
#define SAOKOLINE_H

#include <armadillo>
#include "pomocneFunkcije.h"

using namespace arma;

void zamena(urowvec X, urowvec& novoX);

void inverzija(urowvec X, urowvec& novoX);

void permutacija(urowvec X, urowvec& novoX);

void okolinaInverzija(urowvec X, urowvec& novoX);

void okolinaPermutacija(urowvec X, urowvec& novoX);

#endif
