#ifndef POMOCNEFUNKCIJE_H
#define POMOCNEFUNKCIJE_H

#include <armadillo>
#include <algorithm>// std::random_shuffle


int randint(int i);

arma::uvec setdiff(arma::uvec v, arma::uvec u);

arma::urowvec setdiff2(arma::urowvec v, arma::urowvec u);

arma::urowvec setdiff2(arma::urowvec v, arma::urowvec u);

arma::uvec randsample(arma::uvec v, int k);

arma::rowvec randsample2(arma::rowvec v, int k);

#endif
