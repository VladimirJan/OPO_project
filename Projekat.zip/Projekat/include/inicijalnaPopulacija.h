#ifndef INICIJALNAPOPULACIJA_H
#define INICIJALNAPOPULACIJA_H

#include <armadillo>
#include "pomocneFunkcije.h"

void inicijalnaPopulacija(int brojPoslova, double T, arma::umat& P, int brojJedinki) ;

#endif
