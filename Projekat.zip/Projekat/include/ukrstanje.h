#ifndef UKRSTAVANJE_H
#define UKRSTAVANJE_H

#include <armadillo>
#include "pomocneFunkcije.h"


void ukrstanje(arma::umat P, arma::umat SP, arma::umat& new_P, arma::vec F, arma::vec SF);

#endif
