#ifndef INICIJALNORESENJE_H
#define INICIJALNORESENJE_H

#include <armadillo>
#include "pomocneFunkcije.h"

void inicijalnoResenje(int brojPoslova, arma::urowvec& X);

#endif
