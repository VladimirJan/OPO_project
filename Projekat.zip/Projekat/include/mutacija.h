#ifndef MUTACIJA_H
#define MUTACIJA_H

#include <armadillo>
#include "pomocneFunkcije.h"

void mutacija(arma::umat& new_G) ;

#endif
