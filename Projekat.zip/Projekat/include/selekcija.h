#ifndef SELEKCIJA_H
#define SELEKCIJA_H

#include <armadillo>

void selekcija(arma::umat P, arma::umat& new_P, arma::vec F, arma::vec& new_F);

#endif
