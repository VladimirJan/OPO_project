#ifndef SA_H
#define SA_H

#include <armadillo>
#include "inicijalnoResenje.h"
#include "verovatnocaPrihvatanja.h"
#include "saOkoline.h"
#include "funkcijaCilja.h"

using namespace arma;


void SA(int brojPoslova,double T,arma::mat C, double& opt,double& t,double& elapsedTime, arma::urowvec& X_best, int hibridizacija);

#endif
