#ifndef UCITAVANJE_H
#define UCITAVANJE_H

#include <armadillo>

void ucitavanje(const char* filename, arma::mat& C, int& brojPoslova, double& T);

#endif
