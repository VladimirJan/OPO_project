#ifndef FUNKCIJAPRILAGODJENOSTI_H
#define FUNKCIJAPRILAGODJENOSTI_H

#include <armadillo>

void funkcijaPrilagodjenosti (arma::umat P,arma::vec& F,arma::mat C, double T, int brojPoslova) ;

#endif
