#ifndef VEROVATNOCAPRIHVATANJA_H
#define VEROVATNOCAPRIHVATANJA_H

#include <armadillo>
#include <cmath>

double verovatnocaPrihvatanja(double staraVrednost, double novaVrednost, double temperatura);

#endif
