#ifndef FUNKCIJACILJA_H
#define FUNKCIJACILJA_H

#include <armadillo>

void funkcijaCilja (arma::mat C, int n, double T, arma::urowvec x, double& fx);

#endif
